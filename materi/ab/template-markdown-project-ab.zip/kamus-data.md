# Kamus Data · Dataset Project AB 2026 · Nusantara Kargo 2025

Data fiktif mata kuliah. Kolom berlabel "Rumus" sudah berisi rumus Excel di file.

## Kiriman · transaksi kiriman 2025, satu baris per resi (±11 ribu baris)
| Kolom | Arti | Satuan |
|---|---|---|
| No_Resi | Nomor resi kiriman | teks |
| Tgl_Pickup | Tanggal barang diambil dari pelanggan | tanggal |
| Hub_Asal | Hub tempat kiriman diproses: Jakarta, Surabaya, Medan, Makassar | teks |
| Layanan | Darat Jawa, Darat Sumatra, Laut Antarpulau, Laut Kawasan Timur, Udara Kilat | teks |
| Kota_Tujuan | Kota penerima | teks |
| Kode_Pelanggan | Kode pengirim; detail di sheet Pelanggan | teks |
| Jenis_Barang | Kategori barang | teks |
| Berat_kg | Berat tertagih | kg |
| SLA_hari | Janji waktu kirim untuk layanan tersebut | hari |
| Tgl_Terima | Tanggal barang diterima penerima | tanggal |
| Lama_Kirim_hari | Rumus: Tgl_Terima − Tgl_Pickup | hari |
| Tepat_Waktu | Rumus: "Ya" bila Lama_Kirim_hari ≤ SLA_hari. OTD = porsi kiriman "Ya" | Ya / Tidak |
| Ongkir_Rp | Pendapatan dari kiriman, sudah dikurangi diskon pelanggan | Rupiah |
| Catatan_Kurir | Catatan bebas dari kurir; sering kosong | teks |

## Pelanggan · 120 pelanggan, satu baris per pelanggan
| Kolom | Arti | Satuan |
|---|---|---|
| Kode_Pelanggan | Kode pelanggan | teks |
| Segmen | Jenis usaha pelanggan | teks |
| Kota | Kota pelanggan (menentukan hub asal) | teks |
| Jenis_Tarif | Reguler, Kontrak, atau Kontrak Proyek | teks |
| Diskon | Potongan dari tarif dasar | % |
| Tanggal_Bergabung | Tanggal mulai menjadi pelanggan atau mulai kontrak | tanggal |

## Armada · 36 truk × 12 bulan 2025
| Kolom | Arti | Satuan |
|---|---|---|
| Bulan | Bulan laporan (tanggal 1) | tanggal |
| Truk_ID / Depo / Tahun_Pembuatan | Identitas truk, depo asal, dan tahun pembuatan | teks / tahun |
| Jumlah_Rit / Rit_Terlambat | Jumlah perjalanan dan perjalanan yang terlambat dari jadwal | rit |
| Km_Tempuh / Liter_Solar | Jarak tempuh dan solar yang dipakai dalam bulan itu | km / liter |
| Harga_Solar_per_Liter | Harga solar yang dibayar perusahaan | Rupiah |
| Biaya_Solar_Rp | Rumus: Liter_Solar × Harga_Solar_per_Liter | Rupiah |
| Biaya_Perawatan_Rp | Biaya servis dan suku cadang bulan itu | Rupiah |
| Hari_Tidak_Operasi | Hari truk tidak bisa jalan (rusak atau servis) | hari |

## Gudang · 5 gudang × 12 bulan 2025
| Kolom | Arti | Satuan |
|---|---|---|
| Kiriman_Keluar | Jumlah kiriman yang keluar dari gudang | kiriman |
| Rata_Hari_di_Gudang | Rata-rata lama barang menginap di gudang | hari |
| Klaim_Rusak / Nilai_Klaim_Rp | Jumlah klaim barang rusak dan nilai gantinya | klaim / Rupiah |
| Klaim_per_1000 | Rumus: Klaim_Rusak ÷ Kiriman_Keluar × 1.000 | klaim per 1.000 kiriman |

## Terminal · 2 terminal peti kemas × bulan, 2022–2025
| Kolom | Arti | Satuan |
|---|---|---|
| Terminal | TPK Utara dan TPK Selatan, dua terminal peti kemas mitra di pelabuhan yang sama | teks |
| Kunjungan_Kapal | Jumlah kapal yang sandar dalam bulan itu | kapal |
| TEU_Total / TEU_Transshipment | Volume peti kemas; transshipment = peti kemas pindah kapal (tarif lebih rendah) | TEU |
| Pendapatan_Rp_juta | Pendapatan layanan peti kemas | juta Rupiah |
| BOR | Berth occupancy ratio: porsi waktu dermaga terpakai | % |
| Waiting_Time_jam | Rata-rata waktu kapal menunggu sebelum sandar | jam |

Kunci penghubung: Kiriman.Kode_Pelanggan → Pelanggan.Kode_Pelanggan.
