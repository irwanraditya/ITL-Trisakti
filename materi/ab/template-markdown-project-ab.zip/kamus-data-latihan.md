# Kamus Data · Data Latihan · Tiket Layanan Pelanggan Nusantara Kargo 2025

Data fiktif untuk latihan, tidak dinilai. Sheet Tiket: satu baris per tiket, 6.525 baris.

| Kolom | Arti | Satuan |
|---|---|---|
| No_Tiket | Nomor tiket | teks |
| Tgl_Masuk | Tanggal tiket masuk | tanggal |
| Hari | Nama hari dari Tgl_Masuk | teks |
| Kanal | Telepon (hanya hari kerja), WhatsApp, Email, Chat Aplikasi (mulai 1 Agustus 2025) | teks |
| Kategori | Status kiriman, Keterlambatan, Barang rusak, Ubah alamat, Tagihan, Lainnya | teks |
| Hub | Hub yang menangani kiriman: Jakarta, Surabaya, Medan, Makassar | teks |
| Respons_menit | Menit dari tiket masuk sampai balasan pertama agen | menit |
| Selesai_Sekali_Kontak | Ya bila masalah selesai tanpa pelanggan menghubungi lagi | Ya / Tidak |
| Skor_Kepuasan | Survei setelah tiket ditutup, 1 (buruk) sampai 5 (sangat baik). Kosong bila pelanggan tidak mengisi | skor 1–5 |

Pertanyaan direksi (latihan): Tiket keluhan pelanggan semester 2 naik sekitar 40%. Apakah layanan kita memburuk, dan apa yang harus dilakukan tim layanan pelanggan?
