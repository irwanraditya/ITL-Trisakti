# Standar Presentasi · dipakai setiap menyusun slide atau laporan

## 1. SIAP: empat kalimat sebelum membuat slide
- **S · Situation**: yang sudah kita sepakati benar.
- **I · Issue**: apa yang berubah atau rusak.
- **A · Answer**: apa yang sebenarnya dikatakan data.
- **P · Push**: apa yang pembaca harus lakukan, dengan pemilik dan tenggat.

Jika keempat kalimat belum jelas, jangan membuat slide dulu.

## 2. Pilih satu alur cerita
| Alur | Pertanyaan pembaca | Urutan |
|---|---|---|
| Performance Review | Bagaimana hasil kita? | hasil vs target → pendorong selisih → yang sudah dikerjakan → yang dibutuhkan |
| Proposal | Apa yang sebaiknya kita lakukan? | peluang/risiko → opsi → rekomendasi + alasan → biaya, waktu, keputusan |
| Problem Solving | Apa yang salah? | apa yang terjadi (angka) → akar masalah → perbaikan + pemilik → pencegahan |

## 3. Action title: empat bagian
Subjek · kata kerja + arah (dengan angka) · bukti · so what.
Contoh: "Modern Trade turun 17% pada tiga SKU teratas — alokasi darurat Jumat."

## 4. Delapan aturan deck
1. Empat kalimat SIAP ditulis sebelum membuka aplikasi presentasi.
2. Setiap judul slide adalah temuan, bukan label topik.
3. Satu pesan per slide; dua poin berarti dua slide.
4. Kesimpulan di depan, bukti menyusul (answer-first).
5. Satu warna aksen per grafik, sisanya abu.
6. Angka dibulatkan ke satuan tempat keputusan diambil.
7. Sumber dan periode tercantum di slide.
8. Ditutup dengan permintaan yang punya pemilik dan tenggat.

## 5. Uji 6 detik untuk setiap slide
1. Dari judul saja, bisakah pembaca menyebut pesannya?
2. Bisakah mereka menemukan buktinya? Satu elemen yang menarik mata, bukan tiga.
3. Tahukah mereka apa yang terjadi berikutnya? Implikasi atau permintaan terlihat di slide.

## 6. Format draf slide dari AI
| No | Judul (action title) | Bukti: grafik/tabel apa, dari pivot mana | Angka callout | Sumber & periode |

Jangan memakai angka yang belum tercatat di catatan-progres.md.
