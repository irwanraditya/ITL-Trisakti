# Pernyataan Penggunaan AI
(Lampirkan di halaman terakhir laporan.)

- **Alat**: [nama asisten AI] · dipakai pada [tanggal–tanggal]
- **Explain · dipakai untuk**: [mis. menyusun rencana analisis, menulis langkah pivot, mengkritik judul slide]
- **Explain · tidak dipakai untuk**: [mis. menentukan rekomendasi akhir, menulis tebakan awal]
- **Validate · cara saya memeriksa**: [mis. setiap angka dicocokkan dengan pivot di file Excel saya; AI menyebut X, pivot menunjukkan Y, saya pakai Y]
- **Data yang saya unggah ke AI**: [mis. hanya dataset fiktif mata kuliah; tidak ada data kantor atau data pribadi]
- **Account**: Saya memahami dan bertanggung jawab atas setiap angka dan kesimpulan dalam laporan ini.
