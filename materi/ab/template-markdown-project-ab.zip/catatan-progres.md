# Catatan Progres · [Peran saya]
Diperbarui: [tanggal]

## Tebakan awal (ditulis tanpa AI)
[satu kalimat]

## Angka yang sudah saya verifikasi
| Angka | Nilai | Cara mendapat (sheet · pivot/rumus) | Dicek di Excel? |
|---|---|---|---|
| | | | |

## Dugaan yang belum terbukti
- 

## Keputusan yang sudah saya ambil
- 

## Langkah berikutnya
1. 

---
Cara pakai: saat percakapan dengan AI sudah panjang, mulai percakapan baru dan kirim file ini dengan pesan: "Ini catatan progres saya. Lanjutkan dari Langkah berikutnya nomor 1."
